
import { Col, Row } from 'antd';

function Right() {

  return (


    <Row gutter={[16, 16]} justify="center">

      <Col span={24} lg={12}>
        1
      </Col>

      <Col span={24} lg={12}>
        22
      </Col>
    </Row>
  );
}

export default Right;
